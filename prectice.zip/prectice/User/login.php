
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Login</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="icon" type="image/x-icon" href="image/logo_pink.jpg">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

  
</head>

<body>
<section class="vh-100">
  <div class="container-fluid h-custom" >
    <div class="row d-flex justify-content-center align-items-center h-100" >
      <div class="col-md-9 col-lg-6 col-xl-5" style="margin-top: 80px;">
        <img src="./img/1000_F_119425834_QlKb5LQ3gtxyNtmseMJQh41bI4r3jglz.jpg"
          class="img-fluid" alt="Sample image" style="border-radius: 20px;">
      </div>
      <div class="col-md-8 col-lg-6 col-xl-4 offset-xl-1">
      
        <form action="logic.php" method="POST">
          <h1 style="display: flex; justify-content: center; font-family: 'Courier New', Courier, monospace; margin-top: 100px;">Login Here</h1>
            
          <!-- Email input -->
          <div data-mdb-input-init class="form-outline mb-4" style="margin-top: 30px;">
            <input type="email"  name="email" id="form3Example3" autocomplete="off" class="form-control form-control-lg"
              placeholder="Enter a valid email address" />
            
          </div>
<br>
          <!-- Password input -->
          <div data-mdb-input-init class="form-outline mb-3">
            <input type="password" name="pass" id="form3Example4" class="form-control form-control-lg"
              placeholder="Enter password" />
            
          </div>

          <div class="d-flex justify-content-between align-items-center">
            <!-- Checkbox -->
            
            <a href="#!" class="text-body">Forgot password?</a>
          </div>

          <div class="text-center text-lg-start mt-4 pt-2">
          <input class="btn btn-danger py-2 w-100 mb-1" type="submit" name="sub" value="Login" style="margin-top: 8px;">
            <p class="small fw-bold mt-2 pt-1 mb-0">Don't have an account? <a href="reg.php"
                class="link-danger">Register Here</a></p>
          </div>

        </form>
      </div>
    </div>
  </div>
</section>
<div style="display:none;" id="myDiv" class="animate-bottom">
</body>
</html>