<?php
session_start();
if($_SESSION["u"]!=null)
{
	unset($_SESSION["u"]);
	session_destroy();
	header('Location:login.php');
}
else
{
	echo "Error";
}
?>