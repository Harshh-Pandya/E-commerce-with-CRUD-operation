<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="style.css">
    <link
    rel="stylesheet"
    data-purpose="Layout StyleSheet"
    title="Web Awesome"
    href="/css/app-wa-d53d10572a0e0d37cb8d614a3f177a0c.css?vsn=d"
  >

    <link
      rel="stylesheet"
      href="https://site-assets.fontawesome.com/releases/v6.5.2/css/all.css"
    >

    <link
      rel="stylesheet"
      href="https://site-assets.fontawesome.com/releases/v6.5.2/css/sharp-thin.css"
    >

    <link
      rel="stylesheet"
      href="https://site-assets.fontawesome.com/releases/v6.5.2/css/sharp-solid.css"
    >

    <link
      rel="stylesheet"
      href="https://site-assets.fontawesome.com/releases/v6.5.2/css/sharp-regular.css"
    >

    <link
      rel="stylesheet"
      href="https://site-assets.fontawesome.com/releases/v6.5.2/css/sharp-light.css"
    >
</head>
<body>
<?php 
    include 'connect.php';
    session_start();
    $uname = $_SESSION['u'];
    $ssql = "select *from userdata where email='$uname'";
    $res = mysqli_query($con,$ssql);
    $data = mysqli_fetch_assoc($res);
    ?>
    
    <nav>
        <section class="logo-block">
        <h3> <?php echo $data['uname']; ?> </h3>
            <img src="./img/Starbucks.png" alt="" height="70%">
        </section>
        <ul class="menu">
                <li>Home</li>
                <li>Gift</li>
                <li>Order</li>
                <li>Pay</li>
                <li>Store</li>
                <a href="logout.php" style="text-decoration: none; color: black;"><li>Log Out</li></a> 
            </ul>
        <section class="search-block">
        <div>
                <i class="fa-solid fa-magnifying-glass"></i>
                <input type="text" placeholder="Serach Here">
        </section>
        <section class="logo-block">
        <a href="logout.php"><i class="fa-solid fa-user"></i></a>
        </section>
        
    </nav>
    <section class="know-more">
          <div class="box">
            <p>
              Know More
            </p>
          </div>
        </section>
</body>
</html>