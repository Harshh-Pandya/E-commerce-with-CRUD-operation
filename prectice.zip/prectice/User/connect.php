<?php
$con = mysqli_connect('localhost','root','','prectice');
if($con)
{
    //echo "Coonection Done";
}
else
{
    echo "Error in Connection";
}
?>