<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
</head>
<body>
    <?php 
    include 'connect.php';
    session_start();
    $uname = $_SESSION['u'];
    $ssql = "select *from userdata where email='$uname'";
    $res = mysqli_query($con,$ssql);
    $data = mysqli_fetch_assoc($res);
    ?>
    <h1>
        <?php echo $data['uname']; ?>
    </h1>
</body>
</html>