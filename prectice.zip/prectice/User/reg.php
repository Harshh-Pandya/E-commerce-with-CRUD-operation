<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Register</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="icon" type="image/x-icon" href="image/logo_pink.jpg">
 
</head>
<body>
<section class="vh-100">
  <div class="container-fluid h-custom" >
    <div class="row d-flex justify-content-center align-items-center h-100" >
      <div class="col-md-9 col-lg-6 col-xl-5" style="margin-top: 80px;">
        <img src="./img/637838771407445358pmaknX.jpg"
          class="img-fluid" alt="Sample image" style="border-radius: 20px; margin-top: 30px;">
      </div>
      <div class="col-md-8 col-lg-6 col-xl-4 offset-xl-1">
        <form action="userinsert.php" name="user" method="post" enctype="multipart/form-data">
          <h1 style="display: flex; justify-content: center; font-family: 'Courier New', Courier, monospace; margin-top: 100px;">Register Here</h1>

          <!-- Email input -->
          <div data-mdb-input-init class="form-outline mb-4" style="margin-top: 30px;">
            <input type="text" name="txtfname" require id="form3Example3" class="form-control form-control-lg"
              placeholder="Enter Name" />
</div>
          <!-- Password input -->
          <div data-mdb-input-init class="form-outline mb-3">
            <input type="email" name="email" require id="form3Example4" class="form-control form-control-lg"
              placeholder="Enter a valid email" />
          </div>
          <div data-mdb-input-init class="form-outline mb-3">
            <input type="password" id="form3Example4" name="pass" require maxlength="8" minlength="6" class="form-control form-control-lg"
              placeholder="Enter a Password (Minimum 8 Characters)"  />
          </div>
          <div class="col-auto">
      <div class="input-group mb-2">
        <div class="input-group-prepend">
          <div class="input-group-text">+91</div>
        </div>
        <input type="number" name="mob" require class="form-control" id="inlineFormInputGroup" placeholder="Mobile">
      </div>
    </div>
          <div class="form-group"> 
            <label for="fileupload">Upload Your Photo</label>
            <input type="file"  id="fileupload" name="images[]">
          </div>

          <div class="d-flex justify-content-between align-items-center">
            <!-- Checkbox -->
            
            <!-- <a href="#!" class="text-body">Forgot password?</a> -->
          </div>

          <div class="text-center text-lg-start mt-4 pt-2">
          <input class="btn btn-danger py-2 w-100 mb-1" type="submit" name="sub" value="Submit" style="margin-top: 8px;">
            <p class="small fw-bold mt-2 pt-1 mb-0">Already have an account? <a href="login.php"
                class="link-danger">Login Here</a></p>
          </div>

        </form>
      </div>
    </div>
  </div>
</section>
</body>
</html>