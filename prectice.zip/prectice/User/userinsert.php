<?php
include 'connect.php';
session_start();
if(isset($_POST['sub']));
{
    $uploadDir = "uploads/";
    $imageFiles = [];

    foreach ($_FILES['images']['name'] as $key => $name)
    {
        $tmpName = $_FILES['images']['tmp_name'][$key];
        $targetFile = $uploadDir .  basename($name);
        $name = $_POST['txtfname'];
        $email = $_POST['email'];
        $pass = $_POST['pass'];
        $mob = $_POST['mob'];

        if(move_uploaded_file($tmpName, $targetFile))
        {
            $imageFiles[] = $targetFile;
        }

    }

    if(!empty($imageFiles))
    {
        $imageFilesStr = implode(',',$imageFiles);
    

    $ssql = "select email from userdata where email='$email'";
    $res = mysqli_query($con,$ssql);
    $data=mysqli_fetch_row($res);
    if($data)
    {
        echo "<script> alert('Email taken already!');
            window.location.href='reg.php';
            </script>";
    }
    else
    {
        $insert = "insert into userdata values('','$name','$email','$pass',$mob,'$imageFilesStr')";
        $res2 = mysqli_query($con,$insert);
        if($res2)
        {
            $_SESSION['u']=$name;
            echo "<script> alert('Registration Successfuly');
            window.location.href='login.php';
            </script>";
        }
        else
        {
            echo " <script> alert('Error In Insert Query');
            window.location.href='reg.php';
            </script>";
        }
    }
}
    else
    {
        echo "Error in Image upload ";
    }
}
$con->close();
?>