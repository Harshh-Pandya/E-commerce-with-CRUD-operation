<?php 
session_start();
include 'connect.php';
if(isset($_POST['sub']))
{
    $email=$_POST['email'];
    $pass=$_POST['pass'];

    $ssql="select * from userdata where email='$email' && pass='$pass'";
    $res=mysqli_query($con,$ssql);
    $result=mysqli_fetch_assoc($res);
    if($result==null)
    {
        echo "<script> alert('Please Enter Correct Data');
        window.location.href='login.php';
        </script>";

    }
    else
    {
         $_SESSION['u']=$email;
        echo "<script> alert('Login Successfully');
        window.location.href='index.php';
        </script>";
    }
}
else
{
    echo "Error";
}
?>
